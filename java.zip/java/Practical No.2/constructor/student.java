class student {

student()
{
System.out.print("constroctor called .....");
}
public static void main (String [] args)
{
student s =new student();
}
}




