class ConstructorDemo {
int height, length, width;
ConstructorDemo() {
height = 10;
length = 20;
width = 30;
}
int calValue()
 {
return height * length * width;
}

public static void main(String[] args) {
       
ConstructorDemo d1 = new ConstructorDemo();
ConstructorDemo d2 = new ConstructorDemo();
int value;
value = d1.calValue();
System.out.println("Volume of box1 is " + value);
value = d2.calValue();
System.out.println("Volume of box2 is " + value);
}
}
