class Paraconstructordemo {
int height, length, width;
Paraconstructordemo(int h, int l, int w) {
height = h;
length = l;
width = w;
}
int calVolume() {
return height * length * width;
}
public static void main(String[] args) {
Paraconstructordemo d1 = new 
Paraconstructordemo(5, 7, 8);

Paraconstructordemo d2 = new 
Paraconstructordemo(89, 65, 56);

int volume;
volume = d1.calVolume();
System.out.println("Volume of box 1 is " + volume);
volume = d2.calVolume();
System.out.println("Volume of box 2 is " + volume);
}
}
