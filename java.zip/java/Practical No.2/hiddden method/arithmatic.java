class arithmatic {
void add(int a, int b) {
System.out.print("addition is " + (a + b));
}
void add(int a, int b, int c) 
{
System.out.print("addition is " + (a + b + c));
}

public float add(float a, float b) {
return a + b;
}

public static void main(String[] args) {
arithmatic a = new arithmatic();
a.add(10, 40);
a.add(34, 54, 65);
}
}
