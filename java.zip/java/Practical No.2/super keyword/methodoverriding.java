class A{
void show()
{
System.out.println("Now I am inside show() of superclass A");
}
}
class B extends A{
void show()
{
System.out.println("Now I am inside show() of subclass B");
//super.show();
}
}
class methodoverriding {
public static void main (String [] args)
{
B  b = new B();
b.show();
}
}