class v1{
int a;
}
class v2 extends v1{
int a;
v2(int x, int y)
{
a=x;
super.a=y;
}
void show()
{
System.out.println("value of a of subclass is"+a);
System.out.println("value of a of superclass is"+a);
}
}
class variableoverriding{
public static void main(String[]args)
{
v2 x=new v2(10,20);
x.show();
}
}