class A{
int a,b;
A ( int x, int y)
{
a=x;
b=y;
}
void show()
{
System.out.println("value of a is"+a +"and value of b is "+b);
}
}
class B extends A{
super(x,y);
c=2;
}
void showc()
{
System.out.println("value of c is" +c);
}
}