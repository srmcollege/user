class volume{
int height;
int length;
int width;
int  showvolume()
{
return (height*length*width);
}
}
class volumedemo{
public  static  void  main (String [] args)
{
volume v1=new volume();
volume v2=new volume();
v1.height=56;
v1.length=76;
v1.width=44;

v2.height=67;
v2.length=65;
v2.width=23;

System.out.println("volume of v1 is:-"+v1.showvolume());
System.out.println("volume of v2 is:-"+v2.showvolume());
}
}







