class ConstructorOverload {
int a;
int b;

// Default constructor
ConstructorOverload() {
a = 0;
b = 0;
}
// Constructor with one parameter
ConstructorOverload(int valueA) {
a = valueA;// assign parameter to instance variable
b = 0; // Initialize b to default value, because it not provided
}
// Constructor with two parameters
ConstructorOverload(int valueA, int valueB) {
a = valueA;
b = valueB;
}
void display() {
System.out.println("a: " + a + ", b: " + b);
}
public static void main(String[] args) {
ConstructorOverload obj1 = new ConstructorOverload(); // Calls default constructor
ConstructorOverload obj2 = new ConstructorOverload(5); // Calls constructor with one parameter
ConstructorOverload obj3 = new ConstructorOverload(56, 35); // Calls constructor with two parameters

obj1.display();
obj2.display();
obj3.display();
}
}
