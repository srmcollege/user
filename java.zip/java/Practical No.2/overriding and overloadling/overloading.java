class overloading {
void add(int a, int b)
{
System.out.println("Addition is" +(a+b));
}
void add(int a ,int b ,int c)
{
System.out.println("Addition is" +(a+b+c));
}
double add(double a, double b)
{
return a+b;
}
public static void main(String[] args)
{
overloading a = new overloading ();
a.add(10,20);
a.add(10,20,30);
double f=a.add(10.5,20.4654);
System.out.println("Addition is" +f);
}
}
