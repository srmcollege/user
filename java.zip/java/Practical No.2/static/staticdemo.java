class StaticDemo {
static int a = 5;
static int b;
static int c = 500;

static {
b = a * 10;
}

static void show(int x) {
System.out.println("Value of a is " + a);
System.out.println("Value of b is " + b);
System.out.println("Value of c is " + c);
}
public static void main(String[] args)
 {
show(100);
System.out.println("Value of a is " + a);
System.out.println("Value of c is " + StaticDemo.c);
}
}
