class A {
int a, b;
void show() 
{
System.out.println("Value of a is " + a + " and value of b is " + b);
}
}
class B extends A 
{
int c;
void show() 
{
System.out.println("Value of c is " + c);
}
void add() 
{
System.out.println("Addition of a, b, and c is " + (a + b + c));
}
}

public class InheritanceDemo
{
public static void main(String[] args) 
{
A x = new A();
x.a = 5; 
x.b = 10;

B y = new B();
y.a = 100;
y.b = 200;
y.c = 300;

System.out.println("Content of superclass A is:");
x.show();

System.out.println("Content of subclass B is:");
y.show();
y.add();
}
}