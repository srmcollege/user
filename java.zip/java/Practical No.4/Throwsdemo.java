class Throwsdemo{
static int a=100,b=0,c;
public static void show() throws ArithmeticException
{
c=a/b;
System.out.println("this is not going to print");
}
public static void main(String[] args){
try{
show();
}catch(ArithmeticException e)
{
System.out.println("Arithmetic" +e);
}
System.out.println("Good bye....");
}
}


