class InvalidPhoneNumberException extends Exception {
InvalidPhoneNumberException(String s)
{
super(s);
}
}
class CustomExceptionDemo2 {
static void validate_phone_number(String phonenumber ) throws
InvalidPhoneNumberException {
if(phonenumber  ==  null){
throw new InvalidPhoneNumberException("invalid Number");
}
else {
System.out.println("valid Number");
}
}
public static void main(String[] args){
String number = null;
try{
validate_phone_number(number);
}catch(InvalidPhoneNumberException e1){;
System.out.println("exception found in" +e1);
}
}
}


