class InvalidAgeException extends Exception {
InvalidAgeException(String s)
{
super(s);
}
}
class CustomExceptionDemo {
static void validate_age(int age) throws
InvalidAgeException {
if(age<18){
throw new InvalidAgeException("invalid Age value");
}
else {
System.out.println("Eligible For Voting");
}
}
public static void main(String[] args){
int age=16;
try{
validate_age(age);
}catch(InvalidAgeException e1){;
System.out.println("exception found in" +e1);
}
}
}



