class InvalidNameException extends Exception {
InvalidNameException(String s)
{
super(s);
}
}
class CustomExceptionDemo1 {
static void validate_name(String name) throws
InvalidNameException {
if(name  ==  null){
throw new InvalidNameException("invalid Name value");
}
else {
System.out.println("valid name");
}
}
public static void main(String[] args){
String name = null;
try{
validate_name(name);
}catch(InvalidNameException e1){;
System.out.println("exception found in" +e1);
}
}
}

