// connection code
import java.sql.*;

class Jdbcdemo1 {
    public static void main(String args[]) {
        try {
            // Load JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("Driver loaded successfully...");

            // Establish connection
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "manager");
            System.out.println("Connection established successfully...");
}
catch (Exception e) {
            System.out.println("Exception found is: " + e);
        }
    }
}
