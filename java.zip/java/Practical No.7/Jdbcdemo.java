import java.sql.*;

class Jdbcdemo {
    public static void main(String args[]) {
        try {
            // Load JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("Driver loaded successfully...");

            // Establish connection
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "manager");
            System.out.println("Connection established successfully...");

            // Create statement
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO pranav VALUES (1,'pranav nalang','Pawashi')");

            // Execute query
            ResultSet rs = stmt.executeQuery("SELECT * FROM pranav");
            int i = 1;
            System.out.println("rollno\tname\taddress");

            while (rs.next()) {
                /*
                System.out.println("rollno is " + rs.getInt(1));
                System.out.println("name is " + rs.getString(2));
                System.out.println("address is " + rs.getString(3));
                */
                System.out.println(rs.getInt(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3));
            }

            // Execute update to delete record
           // stmt.executeUpdate("DELETE FROM pranav WHERE rollno = 1");

         
        } catch (Exception e) {
            System.out.println("Exception found is: " + e);
        }
    }
}