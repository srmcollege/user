class onediarray{
public static void main(String[] args)
{
//define array in all possible ways
int a[]={10,20,30,40};
int b[]=new int[5];
b[0]=100;
b[1]=200;
b[2]=300;
b[3]=400;
b[4]=500;
int c[];
c=new int[5];
b[0]=1000;
b[1]=2000;
b[2]=3000;
b[3]=4000;
b[4]=5000;
System.out.println("printing elements of array a");
int x=a.length;
for(int i =0;i<x;i++)
{
System.out.println("Element in array a at index" + i + " is " +a[i]);
}
}
}