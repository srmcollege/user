class whileloop {
public static void main(String[] args)
{
int i=1;
System.out.println("Working with while loop...");
while(i<=10)
{
System.out.println("Current value of i is" +i);
i++;
}
System.out.println("loop terminated...");
}
}