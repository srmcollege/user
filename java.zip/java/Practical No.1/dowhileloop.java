class dowhileloop{
public static void main(String[] args)
{
int i=1;
System.out.println("Working with dowhile loop....");
do
{
System.out.println("current value of i is"+i);
i++;
}
while(i<=10);
System.out.println("Loop terminated...");
}
}