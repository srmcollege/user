class myclass{
public static void main(String[] args)
{
System.out.println("Welcome to java programming");
System.out.println("This is second line");
System.out.println("Good bye....");
}
}


