class forloop{
public static void main(String[] args)
{
int i;
System.out.println("Working with for loop..");
for(i=1; i<=10; i++)
{
System.out.println("Working with for loop....");
{
System.out.println("Current value of i is "+i);
}
System.out.println("loop terminated....");
}
}
}