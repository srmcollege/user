class variable{
public static void main(String[] args)
{
//variable declaration
int a=15,b=5,c;
c=a/b;
System.out.println("Welcome to java programming");
System.out.println("Division of a/b is"+c);
System.out.println("Value of a is " +a +"value of b is" +b +"and their division is" +c);
}
}