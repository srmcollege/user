class twodiarray{
public static void main(String[] args)
{
int a[][]={{1,2,3},{4,5,6},{3,5,7}};
int i,j;
for (i=0;i<3;i++)
{
for(j=0;j<3;j++)
System.out.println(a[i][j] + " ");
}
System.out.println();
}
}