class commandline2 {
public static void main(String[] args)
{
System.out.println("Working with commandline arguments");
int x = args.length;
System.out.println("You passed " + x + " commandline argument");
int num1=Integer.parseInt(args[0]);
int num2=Integer.parseInt(args[1]);
System.out.println("Addition of Commandline argument is" +(num1 + num2));
}
}

