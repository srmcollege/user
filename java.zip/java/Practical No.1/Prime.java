class Prime{
public static void main(String[] args)
{
int num= 29;
int i=2;
boolean flag=false;
while(i<=num/2){
if(num%i==0){
flag=true;
break;
}
++i;
}
if(!flag)
System.out.println(num+"is prime number.");
else
System.out.println(num+"is not prime number.");
}
}