class factorial{
public static void main(String [] args){
int fact=1;
int number=5;
for(int i=1;i<=number;++i)
{
fact*=i;
}
System.out.printf("factorial of %d = %d",number,fact);
}
}