class commandline {
public static void main(String[] args)
{
System.out.println("Working with commandline arguments");
int x = args.length;
System.out.println("You passed " + x + " commandline argument(s)");
for (int i = 0; i < x; i++) {
System.out.println("Commandline argument at index " + i + " is " + args[i]);
}
}
}
