class twodiarray2{
public static void main (String args[])
{
int a[][]=new int[3][2];
a[0][0]=1;
a[0][1]=2;
a[1][0]=3;
a[1][1]=4;
a[2][0]=5;
a[2][2]=6;
int i,j;
for(i=0;i<3;i++)
{
for(j=0;j<2;j++)
{
System.out.print(a[i][j] +" ");
}
System.out.println();
}
}
}
