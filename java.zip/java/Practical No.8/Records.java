import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

class Records extends JFrame implements ActionListener {
static Connection con;
static Statement stmt;

JTextField ID, Name, Address, Phone, Email;
JButton Add, Clear;

Records() {
// Layout and Font
FlowLayout f = new FlowLayout();
setLayout(f);
Font f1 = new Font("Times New Roman", Font.BOLD, 20);

// Labels
JLabel l1 = new JLabel("Enter your ID");
JLabel l2 = new JLabel("Enter your Name");
JLabel l3 = new JLabel("Enter your Address");
JLabel l4 = new JLabel("Enter your Phone");
JLabel l5 = new JLabel("Enter your Email");

// Text Fields
ID = new JTextField(20);
Name = new JTextField(20);
Address = new JTextField(20);
Phone = new JTextField(20);
Email = new JTextField(20);

// Buttons
Add = new JButton("ADD");
Clear = new JButton("CLEAR");

// Set Font
l1.setFont(f1);
l2.setFont(f1);
l3.setFont(f1);
l4.setFont(f1);
l5.setFont(f1);
ID.setFont(f1);
Name.setFont(f1);
Address.setFont(f1);
Phone.setFont(f1);
Email.setFont(f1);
Add.setFont(f1);
Clear.setFont(f1);

// Action Listeners
Add.addActionListener(this);
Clear.addActionListener(this);

// Panel Setup
JPanel p = new JPanel();
p.setLayout(new GridLayout(6, 2)); // Corrected layout with grid layout for 6 rows and 2 columns

// Add components to panel
p.add(l1); p.add(ID);
p.add(l2); p.add(Name);
p.add(l3); p.add(Address);
p.add(l4); p.add(Phone);
p.add(l5); p.add(Email);
p.add(Add); p.add(Clear);

// Add panel to the frame
add(p);
// Frame settings
setSize(400, 300);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}

public void actionPerformed(ActionEvent ae) {
if (ae.getSource() == Clear) {
// Clear all text fields
ID.setText("");
Name.setText("");
Address.setText("");
Phone.setText("");
Email.setText("");
} else if (ae.getSource() == Add) {
try {
// Collect data from text fields
int id = Integer.parseInt(ID.getText());
String nm = Name.getText();
String ad = Address.getText();
String ph = Phone.getText();
String em = Email.getText();

// Insert into database
stmt.executeUpdate("INSERT INTO Pranav2 VALUES(" + id + ",'" + nm + "','" + ad + "','" + ph + "','" + em + "')");

// Show success message
JOptionPane.showMessageDialog(this, "Record Inserted Successfully");
} catch (Exception e) {
JOptionPane.showMessageDialog(this, "Exception Caught: " + e);
}
}
}
public static void main(String[] args) {
// Create the frame
Records w = new Records();
w.setVisible(true);

try {
// Setup database connection
Class.forName("oracle.jdbc.driver.OracleDriver");
con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "manager");
stmt = con.createStatement();
} catch (Exception e) {
e.printStackTrace();
}
}
}
