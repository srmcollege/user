import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Biodata extends JFrame {
Biodata(String title) {
super(title);
Container cp = getContentPane();
cp.setLayout(null);
cp.setBackground(Color.ORANGE);
Font f = new Font("Times New Roman", Font.BOLD, 20);

// Create Labels
JLabel lblName = new JLabel("Enter your Name:");
JLabel lblEmail = new JLabel("Enter your Email:");
JLabel lblContact = new JLabel("Enter your Contact Number:");
JLabel lblAddress = new JLabel("Enter your Address:");
JLabel lblState = new JLabel("Select your State:");
JLabel lblDistrict = new JLabel("Select your District:");
JLabel lblGender = new JLabel("Select your Gender:");
JLabel lblHobbies = new JLabel("Select your Hobbies:");

// Create Text Fields and Text Area
JTextField txtName = createTextField();
JTextField txtEmail = createTextField();
JTextField txtContact = createTextField();
JTextArea txtAddress = createTextArea();
JComboBox<String> cbState = createComboBox(new String[]{"Maharashtra", "Goa", "Gujarat"});

JComboBox<String> cbDistrict = createComboBox(new String[]{"Sindhudurg", "Kohlapur", "Ratnagiri"});

JComboBox<String> cbGender = createComboBox(new String[]{"Male", "Female", "Other"});

JComboBox<String> cbHobbies = createComboBox(new String[]{"Reading", "Traveling", "Sports","Dancing"});

// Set bounds for labels and fields
lblName.setBounds(50, 50, 200, 30);
txtName.setBounds(250, 50, 200, 30);

lblEmail.setBounds(50, 100, 200, 30);
txtEmail.setBounds(250, 100, 200, 30);

lblContact.setBounds(50, 150, 200, 30);
txtContact.setBounds(250, 150, 200, 30);

lblAddress.setBounds(50, 200, 200, 30);
txtAddress.setBounds(250, 200, 200, 60);

lblState.setBounds(50, 270, 200, 30);
cbState.setBounds(250, 270, 200, 30);

lblDistrict.setBounds(50, 320, 200, 30);
cbDistrict.setBounds(250, 320, 200, 30);

lblGender.setBounds(50, 370, 200, 30);
cbGender.setBounds(250, 370, 200, 30);

lblHobbies.setBounds(50, 420, 200, 30);
cbHobbies.setBounds(250, 420, 200, 30);

// Adding components to the container
cp.add(lblName);
cp.add(txtName);
cp.add(lblEmail);
cp.add(txtEmail);
cp.add(lblContact);
cp.add(txtContact);
cp.add(lblAddress);
cp.add(txtAddress);
cp.add(lblState);
cp.add(cbState);
cp.add(lblDistrict);
cp.add(cbDistrict);
cp.add(lblGender);
cp.add(cbGender);
cp.add(lblHobbies);
cp.add(cbHobbies);

// Set JFrame properties
setSize(500, 600);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setVisible(true);
}

// Method to create a JTextField with a default of 20 columns
private JTextField createTextField() {
return new JTextField(20);
}

// Method to create a JTextArea with default size of 3 rows and 20 columns
private JTextArea createTextArea() {
return new JTextArea(3, 20);
}

// Method to create a JComboBox with a specified list of items
private JComboBox<String> createComboBox(String[] items) {
return new JComboBox<>(items);
}

public static void main(String[] args) {
new Biodata("Biodata Form");
}
}
