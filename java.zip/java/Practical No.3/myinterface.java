public interface myinterface{
final int a=500;
final int b=200;
public void show();
public int add(int x,int y);
}