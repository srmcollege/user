class Access {
int a; 
public int b; 
public int c; 
protected int d; 
    
private void display() {
System.out.println("Value of a: " + a);
System.out.println("Value of b: " + b);
System.out.println("Value of c: " + c);
System.out.println("Value of d: " + d);
}
public void show() {
c = 30;
display(); 
}}
class AccessSpecifier {
public static void main(String[] args) {
Access obj = new Access();
obj.a = 10; 
obj.b = 20; 
obj.c = 30; 
obj.d = 40; 
obj.show(); 
}
}
