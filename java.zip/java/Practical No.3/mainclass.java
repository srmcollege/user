class myinterfaceimp implements myinterface{
int c;
public void show(){
System.out.print("inside the show()");
}
public int add(int x,int y){
return x+y;
}
void display()
{
c=a+b;
System.out.print("Addition is" +c);
}}
class mainclass{
public static void main(String[] args)
{
myinterfaceimp m=new myinterfaceimp();
m.show();
m.display();
int x=m.add(100,200);
System.out.println("Addition is" +x);
}}