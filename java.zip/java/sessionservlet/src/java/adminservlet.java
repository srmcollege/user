/*
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class adminservlet extends HttpServlet {
    public void service(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
{
  PrintWriter pw=response.getWriter();
  response.setContentType("text/html");
   pw.println("welcome on this common page.....");
   HttpSession hs=request.getSession();
   String id=(String)hs.getAttribute("ID");
   String password=(String)hs.getAttribute("PASSWORD");
   if(id !=null) && null!=password){
    if(id.equals("admin") && password.equals("admin1234")){
        pw.println("welcome on this admin page");
    }
    else{
        pw.println("you are not admin...........please login as admin user");
        RequestDispatcher rd=request.getRequestDispatcher("index.html");
        rd.include(request, response);
    }
}
   else{
           pw.println("please login....");
           RequestDispatcher rd=request.getRequestDispatcher("index.html");
        rd.include(request, response);
           }
}
}

*/



import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;

public class adminservlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        PrintWriter pw = response.getWriter();
        response.setContentType("text/html");
       

        HttpSession session = request.getSession();
        String id = (String) session.getAttribute("ID");
        String password = (String) session.getAttribute("PASSWORD");

        if (id != null && password != null) {
            if (id.equals("admin") && password.equals("admin1234")) {
                pw.println("Welcome to the admin page.");
            } else {
                pw.println("You are not an admin. Please log in as an admin user.");
                RequestDispatcher rd = request.getRequestDispatcher("index.html");
                rd.include(request, response);
            }
        } else {
            pw.println("Please log in...");
            RequestDispatcher rd = request.getRequestDispatcher("index.html");
            rd.include(request, response);
        }
    }
}
