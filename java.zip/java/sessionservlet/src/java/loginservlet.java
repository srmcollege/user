
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class loginservlet extends HttpServlet {
@Override
public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
{
  PrintWriter pw=response.getWriter();
  response.setContentType("text/html");
  String uid=request.getParameter("id");
  String upassword=request.getParameter("password");
   HttpSession hs=request.getSession();
   hs.setAttribute("ID",uid);
   hs.setAttribute("PASSWORD", upassword);
   response.sendRedirect("homeservlet");
}
}
