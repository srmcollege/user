
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class homeservlet extends HttpServlet {

public void service(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
{
  PrintWriter pw=response.getWriter();
  response.setContentType("text/html");
  pw.println("welcome on home page<br><br>");
  pw.println("<a href='commonservlet'>Go to common page</a> <br>");
  pw.println("<a href='adminservlet'>Go to admin page</a> <br>");
  
}
   }
