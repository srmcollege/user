import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Calci extends JFrame implements ActionListener {
JTextField t1,t2,t3;
JButton add,clear,sub,multiply,division,exit;

Calci(String s)
{
super(s);
FlowLayout f=new FlowLayout();
setLayout(f);
Font f1 = new Font("times New Roman",Font.BOLD,20);

JLabel l1 = new JLabel("enter first number");
JLabel l2 = new JLabel("enter second number");
JLabel l3 = new JLabel("Result");

t1 = new JTextField(10);
t2 = new JTextField(10);
t3 = new JTextField(10);

add = new JButton("ADD");
clear = new JButton("CLEAR");
sub = new JButton("SUB");
multiply = new JButton("MULTIPLY");
division = new JButton("DIVISION");
exit = new JButton("EXIT");


l1.setFont(f1);l2.setFont(f1);l3.setFont(f1);t1.setFont(f1);t2.setFont(f1);t3.setFont(f1);
add.setFont(f1);clear.setFont(f1);sub.setFont(f1);multiply.setFont(f1);division.setFont(f1);exit.setFont(f1);

add.addActionListener(this);
clear.addActionListener(this);
exit.addActionListener(this);
sub.addActionListener(this);
multiply.addActionListener(this);
division.addActionListener(this);

JPanel p =new JPanel();
p.setSize(400,300);
p.setLayout(new GridLayout(7, 2));
p.add(l1);p.add(t1);p.add(l2);p.add(t2);p.add(l3);p.add(t3);
p.add(add);p.add(clear);p.add(sub);p.add(exit);p.add(multiply);p.add(division);add(p);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}

public void actionPerformed(ActionEvent ae){
int x = Integer.parseInt(t1.getText());
int y = Integer.parseInt(t2.getText());
if(ae.getSource() == add) {
t3.setText(" "+(x+y));
} else if(ae.getSource()==clear) {
t1.setText("");
t2.setText("");
t3.setText("");
} else if(ae.getSource() == exit) {
System.exit(0);
} else if (ae.getSource() == sub) {
t3.setText("" + (x - y));
} else if (ae.getSource() == multiply) {
t3.setText("" + (x * y));
} else if (ae.getSource() == division) {
t3.setText("" + (x / y));
}
}
}


class Calculator {
public static void main(String args[ ] )
{
Calci c = new Calci("CALCULATOR");
c.setSize(600,400);
c.setVisible(true);
}
}
