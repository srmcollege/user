
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
@Override
public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
{
  PrintWriter pw=response.getWriter();
  response.setContentType("text/html");
  String uid=request.getParameter("id");
  String upassword=request.getParameter("password");
  
  Cookie c1=new Cookie("id",uid);
  Cookie c2=new Cookie("password",upassword);
  
  response.addCookie(c1);
  response.addCookie(c2);
  pw.println("cookies are created on server and now stored on client");
}
}
