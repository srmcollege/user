
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class AdminServlet extends HttpServlet {
public void service(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
{
    PrintWriter pw=response.getWriter();
    response.setContentType("text/html"); 
    Cookie[] cookies=request.getCookies();
    if(cookies != null){
        pw.println("cookies found.....");
        String id=cookies[0].getValue();
        String password=cookies[1].getValue();
        if(id.equals("admin") && password.equals("admin1234")){
            pw.println("welcome on ADMIN page");
        }
        else{
            pw.println("you are not a admin...<br> please log in with admin identity");
            RequestDispatcher r1=requestDispatcher("index.html");
            r1.include(request,response);
        }
    }
    else{
       pw.println("login in thr system and try to access the admin page");
       RequestDispatcher r1=requestDispatcher("index.html");
            r1.include(request,response);
    }
}
    private RequestDispatcher requestDispatcher(String indexhtml) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
